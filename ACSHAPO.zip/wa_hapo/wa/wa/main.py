from flask import Flask, render_template, request, jsonify, redirect

app = Flask(__name__)

nicknames = set()
registrace_data = []

def is_valid_nickname(nick):
    return nick.isalnum() and 2 <= len(nick) <= 20

@app.route('/api/check-nickname', methods=['GET'])
def check_nickname():
    nick = request.args.get('nick')
    if nick in nicknames:
        return jsonify({"exists": True})
    else:
        return jsonify({"exists": False})

@app.route('/', methods=['GET'])
def index():
    return render_template('prvni_stranka.html', ucastnici=registrace_data), 200

@app.route('/registrace', methods=['GET', 'POST'])
def registration():
    if request.method == 'GET':
        return render_template('registrace.html')
    if request.method == 'POST':
        data = request.form
        nick = data.get('nick')
        je_plavec = data.get('je_plavec')
        kanoe_kamarad = data.get('kanoe_kamarad')

        if nick in nicknames:
            return jsonify({"error": "Tento nickname již existuje. "}), 400
        nicknames.add(nick)

        if je_plavec != 'Ano':
            return jsonify({"error": "Osoba musi byt plavec."}), 400

        if not is_valid_nickname(nick):
            return jsonify({"error": "Neplatny nick. "}), 400

        if kanoe_kamarad and not is_valid_nickname(kanoe_kamarad):
            return jsonify({"error": "Neplatny kamarad na kanoji."}), 400

        registrace_data.append({"nick": nick, "je_plavec": je_plavec, "kanoe_kamarad": kanoe_kamarad})

        return redirect("/")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
